﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rito
{
    class RitoMath
    {
        /// <summary> 정수를 0, 1 값으로 디지털화하여 리턴 </summary>
        public static int Digitalize(int intValue)
        {
            if (intValue.Equals(0)) return 0;
            return 1;
        }

        /// <summary> 실수를 0, 1 값으로 디지털화하여 리턴 </summary>
        public static float Digitalize(float floatValue)
        {
            if (floatValue.Equals(0f)) return 0f;
            return 1f;
        }

        /// <summary> 정수를 -1, 0, 1 값으로 변환하여 리턴 </summary>
        public static int SignedDigitalize(int intValue)
        {
            if (intValue < 0) return -1;
            if (intValue > 0) return 1;
            return 0;
        }

        /// <summary> 실수를 -1, 0, 1 값으로 변환하여 리턴 </summary>
        public static float SignedDigitalize(float floatValue)
        {
            if (floatValue < 0f) return -1f;
            if (floatValue > 0f) return 1f;
            return 0f;
        }


    }
}
