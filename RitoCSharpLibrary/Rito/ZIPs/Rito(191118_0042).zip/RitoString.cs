﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rito
{
    class RitoString
    {
        /// <summary>
        /// 시작 문자(열)부터 끝 문자(열)까지 자르기<para/>
        /// 자를 위치 시작, 끝 각각 보정 가능(왼쪽은 -1, 오른쪽은 +1)
        /// </summary>
        public static string Substring(string fullString, string start, string end,
                                        int startIndexMove = 0, int endIndexMove = 0)
        {
            if (fullString.Length <= start.Length) return fullString;
            if (fullString.Length <= end.Length) return fullString;

            int startIndex = fullString.IndexOf(start);
            int endIndex = fullString.IndexOf(end);

            // move 보정
            if (startIndex + startIndexMove >= 0 && startIndex + startIndexMove < fullString.Length - 1)
                startIndex += startIndexMove;

            if (endIndex + endIndexMove >= 0 && endIndex + endIndexMove < fullString.Length - 1)
                endIndex += endIndexMove;


            int subLength = endIndex - startIndex + 1; // 서브스트링의 길이


            return fullString.Substring(startIndex, subLength);
        }

        /// <summary> 스트링을 특정 토큰으로 분리하여 스트링 리스트에 추가 </summary>
        public static void Tokenize(ref List<string> strList, string srcString, char token)
        {
            int index = 0;
            int wordEnd;

            while (index < srcString.Length && index != -1)
            {
                while (srcString[index] == token) index++;   // 토큰 지나가기

                wordEnd = srcString.IndexOf(token, index);

                if (wordEnd == -1)   // 끝지점에 도달해서 토큰 대신 스트링의 끝을 만날 경우
                    strList.Add(srcString.Substring(index));
                else                // 스트링 중간에서 토큰을 만나 분리
                    strList.Add(srcString.Substring(index, wordEnd - index));

                index = wordEnd;
            }
        }
    }
}
